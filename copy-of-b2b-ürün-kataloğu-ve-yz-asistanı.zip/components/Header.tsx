
import React from 'react';

interface HeaderProps {
  onNavigate: (view: 'catalog' | 'userProfile' | 'reports') => void;
}

const Header: React.FC<HeaderProps> = ({ onNavigate }) => {
  return (
    <header className="bg-slate-800 text-white p-6 shadow-md sticky top-0 z-50">
      <div className="container mx-auto flex flex-wrap justify-between items-center">
        <h1 
          className="text-3xl font-bold tracking-tight cursor-pointer hover:text-slate-300 transition-colors"
          onClick={() => onNavigate('catalog')}
          role="button"
          tabIndex={0}
          onKeyPress={(e) => e.key === 'Enter' && onNavigate('catalog')}
          aria-label="Ana sayfaya git"
        >
          B2B Ürün Kataloğu ve YZ Asistanı
        </h1>
        <nav className="mt-4 md:mt-0">
          <ul className="flex space-x-4 md:space-x-6">
            <li>
              <button 
                onClick={() => onNavigate('catalog')} 
                className="hover:text-slate-300 transition-colors pb-1 border-b-2 border-transparent hover:border-slate-300"
                aria-label="Ürün kataloğunu görüntüle"
              >
                Ürünler
              </button>
            </li>
            <li>
              <button 
                onClick={() => onNavigate('userProfile')} 
                className="hover:text-slate-300 transition-colors pb-1 border-b-2 border-transparent hover:border-slate-300"
                aria-label="Kullanıcı profilini görüntüle"
              >
                Profilim
              </button>
            </li>
            <li>
              <button 
                onClick={() => onNavigate('reports')}
                className="hover:text-slate-300 transition-colors pb-1 border-b-2 border-transparent hover:border-slate-300"
                aria-label="Satış raporlarını görüntüle"
              >
                Raporlar
              </button>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;