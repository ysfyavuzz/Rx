import React from 'react';
import ReactDOM from 'react-dom/client';
import { SalesSummaryData } from '../types';
import LoadingSpinner from './LoadingSpinner';
import SystemReportContent from './SystemReportContent';

// html2pdf kütüphanesini global scope'tan kullanacağımızı belirtiyoruz
declare const html2pdf: any;

interface ReportsPageProps {
  summaryData: SalesSummaryData;
  onGenerateAiAnalysis: () => void;
  isGeneratingAiAnalysis: boolean;
  isApiKeyAvailable: boolean;
}

const ReportsPage: React.FC<ReportsPageProps> = ({ 
    summaryData, 
    onGenerateAiAnalysis,
    isGeneratingAiAnalysis,
    isApiKeyAvailable
}) => {

  const handleDownloadPdfReport = () => {
    const reportRootElementId = 'system-report-render-target';
    let reportRootElement = document.getElementById(reportRootElementId);
    let tempElementCreated = false;

    if (!reportRootElement) {
      reportRootElement = document.createElement('div');
      reportRootElement.id = reportRootElementId;
      // PDF'e düzgün yansıtılması için görünür olmalı ama ekran dışı olabilir
      // Sayfa düzenini etkilememesi için boyutları A4'e yakın ve gizli olmalı
      reportRootElement.style.position = 'fixed'; // fixed veya absolute
      reportRootElement.style.left = '-220mm'; // Ekran dışına taşı
      reportRootElement.style.top = '0';
      reportRootElement.style.width = '210mm'; // A4 genişliği
      reportRootElement.style.height = '297mm'; // A4 yüksekliği (isteğe bağlı)
      reportRootElement.style.zIndex = '-1'; // Diğer elementlerin altında kalsın
      reportRootElement.style.overflow = 'hidden'; // Taşan içerik gizlensin
      document.body.appendChild(reportRootElement);
      tempElementCreated = true;
    }
    
    // reportRootElement'in null olmadığını TypeScript'e bildirmek için type assertion
    const guaranteedReportRootElement = reportRootElement as HTMLElement;
    const reportRoot = ReactDOM.createRoot(guaranteedReportRootElement);
    
    // SystemReportContent'i render et
    reportRoot.render(
      <React.StrictMode>
        <SystemReportContent />
      </React.StrictMode>
    );

    // Render işleminin tamamlanması ve stillerin uygulanması için bekleme
    setTimeout(() => {
      console.log('Rapor elementi HTML PDF oluşturulmadan önce:', guaranteedReportRootElement.innerHTML.substring(0, 500) + "..."); // İlk 500 karakteri logla

      if (typeof html2pdf !== 'undefined') {
        const opt = {
          margin:       [0.5, 0.5, 0.5, 0.5], // top, right, bottom, left (inç cinsinden)
          filename:     'B2B_Sistem_Raporu.pdf',
          image:        { type: 'jpeg', quality: 0.98 },
          html2canvas:  { 
            scale: 2, 
            useCORS: true, 
            letterRendering: true,
            // Bazı durumlarda genişlik ve yükseklik belirtmek gerekebilir
            // width: guaranteedReportRootElement.scrollWidth,
            // height: guaranteedReportRootElement.scrollHeight,
            windowWidth: guaranteedReportRootElement.scrollWidth,
            windowHeight: guaranteedReportRootElement.scrollHeight
          },
          jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' },
          // Sayfa sonlarını daha iyi yönetmek için
          pagebreak:    { mode: ['avoid-all', 'css', 'legacy'] } 
        };

        html2pdf().from(guaranteedReportRootElement).set(opt).save().then(() => {
           // Render edilen geçici elementi temizle
           reportRoot.unmount();
           if (tempElementCreated) {
            guaranteedReportRootElement.remove();
           }
        }).catch((error: any) => {
          console.error("PDF oluşturulurken hata oluştu:", error);
          reportRoot.unmount();
          if (tempElementCreated) {
            guaranteedReportRootElement.remove();
          }
        });
      } else {
        console.error("html2pdf.js kütüphanesi bulunamadı.");
        alert("PDF oluşturma kütüphanesi yüklenemedi. Lütfen sayfanın tam olarak yüklendiğinden emin olun ve tekrar deneyin.");
        reportRoot.unmount();
        if (tempElementCreated) {
            guaranteedReportRootElement.remove();
        }
      }
    }, 1000); // Bekleme süresini 1000ms (1 saniye) olarak artırdık
  };

  return (
    <div className="space-y-8">
      <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-8 text-center">Satış ve Performans Raporları</h1>

      {/* Sales Summary Cards */}
      <section aria-labelledby="sales-summary-heading">
        <h2 id="sales-summary-heading" className="text-2xl font-semibold text-gray-700 mb-4">Genel Özet</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white p-6 rounded-xl shadow-lg">
            <h3 className="text-lg font-medium mb-1">Toplam Gelir</h3>
            <p className="text-4xl font-bold">${summaryData.totalRevenue.toLocaleString('tr-TR', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</p>
          </div>
          <div className="bg-gradient-to-br from-green-500 to-green-600 text-white p-6 rounded-xl shadow-lg">
            <h3 className="text-lg font-medium mb-1">Toplam Sipariş</h3>
            <p className="text-4xl font-bold">{summaryData.totalOrders.toLocaleString('tr-TR')}</p>
          </div>
          <div className="bg-gradient-to-br from-indigo-500 to-indigo-600 text-white p-6 rounded-xl shadow-lg">
            <h3 className="text-lg font-medium mb-1">Ort. Sipariş Değeri</h3>
            <p className="text-4xl font-bold">${summaryData.averageOrderValue.toLocaleString('tr-TR', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</p>
          </div>
        </div>
      </section>

      {/* Top Selling Products */}
      <section aria-labelledby="top-products-heading">
        <div className="bg-white shadow-xl rounded-lg p-6 md:p-8">
            <h2 id="top-products-heading" className="text-2xl font-semibold text-gray-700 mb-6 border-b pb-3">En Çok Satan Ürünler</h2>
            <ul className="space-y-4">
            {summaryData.topSellingProducts.map((product, index) => (
                <li key={product.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-md hover:bg-gray-100 transition-colors">
                <div>
                    <span className="font-semibold text-gray-800">{index + 1}. {product.name}</span>
                    <span className="text-sm text-gray-500 ml-2">({product.unitsSold} adet)</span>
                </div>
                <span className="font-medium text-green-600">
                    ${product.revenue.toLocaleString('tr-TR', {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                </span>
                </li>
            ))}
            </ul>
        </div>
      </section>

      {/* AI Sales Trend Analysis & PDF Download */}
      <section aria-labelledby="ai-analysis-pdf-download-heading">
        <div className="bg-white shadow-xl rounded-lg p-6 md:p-8">
            <h2 id="ai-analysis-pdf-download-heading" className="text-2xl font-semibold text-gray-700 mb-4">Ek Araçlar ve Raporlar</h2>
            <div className="flex flex-col md:flex-row gap-4">
                {isApiKeyAvailable ? (
                    <button
                        onClick={onGenerateAiAnalysis}
                        disabled={isGeneratingAiAnalysis}
                        className="flex-1 bg-teal-500 hover:bg-teal-600 text-white font-bold py-3 px-6 rounded-lg transition duration-150 ease-in-out disabled:opacity-60 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-teal-500 focus:ring-opacity-75 flex items-center justify-center"
                    >
                        {isGeneratingAiAnalysis ? (
                            <>
                                <LoadingSpinner /> 
                                <span className="ml-2">Analiz Oluşturuluyor...</span>
                            </>
                        ): 'YZ Trend Analizi Oluştur'}
                    </button>
                ) : (
                    <div className="flex-1 text-sm text-amber-700 bg-amber-100 p-3 rounded-md flex items-center justify-center">
                        <p className="text-center">YZ Analiz özelliği devre dışı. Etkinleştirmek için API Anahtarını yapılandırın.</p>
                    </div>
                )}
                <button
                    onClick={handleDownloadPdfReport}
                    className="flex-1 bg-sky-600 hover:bg-sky-700 text-white font-bold py-3 px-6 rounded-lg transition duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-opacity-75 flex items-center justify-center"
                    aria-label="Sistem durum raporunu PDF olarak indir"
                >
                     <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 mr-2">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5M16.5 12 12 16.5m0 0L7.5 12m4.5 4.5V3" />
                    </svg>
                    Sistem Raporunu PDF Olarak İndir
                </button>
            </div>
            {/* The actual AI analysis will be shown in a modal */}
        </div>
      </section>
    </div>
  );
};

export default ReportsPage;