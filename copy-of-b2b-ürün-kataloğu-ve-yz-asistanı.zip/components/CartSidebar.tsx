import React from 'react';
import { CartItem } from '../types';

interface CartSidebarProps {
  cartItems: CartItem[];
  onRemoveFromCart: (productId: string) => void;
  onPlaceOrder: () => void;
  isOpen: boolean;
  onClose: () => void;
}

const CartSidebar: React.FC<CartSidebarProps> = ({ cartItems, onRemoveFromCart, onPlaceOrder, isOpen, onClose }) => {
  const totalAmount = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <div
      className={`fixed top-0 right-0 h-full bg-gray-800 text-white shadow-2xl transition-transform duration-300 ease-in-out w-full sm:w-96 md:w-1/3 lg:w-1/4 z-40 ${
        isOpen ? 'translate-x-0' : 'translate-x-full'
      }`}
      role="dialog"
      aria-modal="true"
      aria-labelledby="cart-sidebar-title"
    >
      <div className="flex flex-col h-full">
        <div className="flex justify-between items-center p-4 border-b border-gray-700">
          <h2 id="cart-sidebar-title" className="text-xl font-semibold">Sepetiniz</h2>
          <button
            onClick={onClose}
            className="text-gray-300 hover:text-white"
            aria-label="Sepeti kapat"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18 18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {cartItems.length === 0 ? (
          <div className="flex-grow flex items-center justify-center p-4">
            <p className="text-gray-400">Sepetiniz boş.</p>
          </div>
        ) : (
          <div className="flex-grow overflow-y-auto p-4 space-y-4">
            {cartItems.map((item) => (
              <div key={item.id} className="flex items-center justify-between bg-gray-700 p-3 rounded-md">
                <div>
                  <h3 className="font-semibold">{item.name}</h3>
                  <p className="text-sm text-gray-300">
                    {item.quantity} x ${item.price.toFixed(2)}
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                    <p className="font-semibold">${(item.price * item.quantity).toFixed(2)}</p>
                    <button
                        onClick={() => onRemoveFromCart(item.id)}
                        className="text-red-400 hover:text-red-300 p-1 rounded-md"
                        aria-label={`${item.name} ürününü sepetten kaldır`}
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                        <path strokeLinecap="round" strokeLinejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12.56 0c1.153 0 2.24.032 3.22.094m9.34-3.105a3.125 3.125 0 0 0-3.125-3.125H9.375A3.125 3.125 0 0 0 6.25 5.79v.217c0 .551.448 1 1 1h10c.552 0 1-.449 1-1v-.217Z" />
                        </svg>
                    </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {cartItems.length > 0 && (
          <div className="p-4 border-t border-gray-700">
            <div className="flex justify-between items-center mb-4">
              <p className="text-lg font-semibold">Toplam:</p>
              <p className="text-xl font-bold">${totalAmount.toFixed(2)}</p>
            </div>
            <button
              onClick={onPlaceOrder}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-md transition duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50"
            >
              Siparişi Ver (Simülasyon)
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default CartSidebar;