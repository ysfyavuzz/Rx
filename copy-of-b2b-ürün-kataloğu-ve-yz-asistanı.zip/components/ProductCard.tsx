
import React from 'react';
import { Product } from '../types';
import LoadingSpinner from './LoadingSpinner';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  onGenerateDescription: (product: Product) => void;
  onGenerateSalesPitch: (product: Product) => void;
  onNavigateToDetail: (productId: string) => void;
  isGenerating: boolean;
  isApiKeyAvailable: boolean;
}

const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onAddToCart,
  onGenerateDescription,
  onGenerateSalesPitch,
  onNavigateToDetail,
  isGenerating,
  isApiKeyAvailable,
}) => {
  const handleProductClick = (e: React.MouseEvent<HTMLHeadingElement, MouseEvent> | React.KeyboardEvent<HTMLHeadingElement>) => {
    if (e.type === 'click' || (e.type === 'keypress' && (e as React.KeyboardEvent).key === 'Enter')) {
        onNavigateToDetail(product.id);
    }
  };
  
  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden flex flex-col transition-all duration-300 hover:shadow-2xl h-full">
      <img 
        className="w-full h-48 object-cover cursor-pointer" 
        src={product.imageUrl} 
        alt={product.name} 
        onClick={() => onNavigateToDetail(product.id)}
        role="button"
        tabIndex={0}
        onKeyPress={(e) => e.key === 'Enter' && onNavigateToDetail(product.id)}
        aria-label={`${product.name} için detayları görüntüle`}
      />
      <div className="p-6 flex flex-col flex-grow">
        <h3 
            className="text-xl font-semibold text-gray-800 mb-2 cursor-pointer hover:text-blue-600 transition-colors"
            onClick={handleProductClick}
            onKeyPress={handleProductClick}
            tabIndex={0}
            role="button"
            aria-label={`${product.name} için detayları görüntüle`}
        >
            {product.name}
        </h3>
        <p className="text-sm text-gray-600 mb-1"><span className="font-medium">Kategori:</span> {product.category}</p>
        <p className="text-sm text-gray-600 mb-4 flex-grow">{product.shortDescription}</p>
        <p className="text-2xl font-bold text-blue-600 mb-4">${product.price.toFixed(2)}</p>
        
        <div className="mt-auto"> {/* Butonların altta olmasını sağlar */}
          <button
            onClick={() => onAddToCart(product)}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-md transition duration-150 ease-in-out mb-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50"
          >
            Sepete Ekle
          </button>

          {isApiKeyAvailable && (
            <div className="mt-2 space-y-2">
              <button
                onClick={() => onGenerateDescription(product)}
                disabled={isGenerating}
                className="w-full bg-green-500 hover:bg-green-600 text-white font-semibold py-2 px-4 rounded-md transition duration-150 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-opacity-50"
              >
                {isGenerating ? <LoadingSpinner /> : 'Açıklamayı Geliştir (YZ)'}
              </button>
              <button
                onClick={() => onGenerateSalesPitch(product)}
                disabled={isGenerating}
                className="w-full bg-indigo-500 hover:bg-indigo-600 text-white font-semibold py-2 px-4 rounded-md transition duration-150 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-opacity-50"
              >
                {isGenerating ? <LoadingSpinner /> : 'Satış Konuşması Oluştur (YZ)'}
              </button>
            </div>
          )}
          {!isApiKeyAvailable && (
            <p className="text-xs text-amber-600 mt-2 text-center">YZ özellikleri devre dışı. API Anahtarı yapılandırılmamış.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductCard;