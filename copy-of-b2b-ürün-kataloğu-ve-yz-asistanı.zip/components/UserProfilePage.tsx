import React from 'react';
import { UserProfileData, Order } from '../types';

interface UserProfilePageProps {
  user: UserProfileData;
  orders: Order[];
}

const UserProfilePage: React.FC<UserProfilePageProps> = ({ user, orders }) => {
  return (
    <div className="space-y-8">
      <section aria-labelledby="user-profile-heading">
        <div className="bg-white shadow-xl rounded-lg p-6 md:p-8">
          <h2 id="user-profile-heading" className="text-2xl md:text-3xl font-semibold text-gray-800 mb-6 border-b pb-4">Profilim</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <p className="text-sm text-gray-500">Ad</p>
              <p className="text-lg text-gray-700 font-medium">{user.name}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">E-posta</p>
              <p className="text-lg text-gray-700 font-medium">{user.email}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Şirket</p>
              <p className="text-lg text-gray-700 font-medium">{user.company}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Üyelik Tarihi</p>
              <p className="text-lg text-gray-700 font-medium">{new Date(user.memberSince).toLocaleDateString('tr-TR')}</p>
            </div>
          </div>
        </div>
      </section>

      <section aria-labelledby="order-history-heading">
        <div className="bg-white shadow-xl rounded-lg p-6 md:p-8">
          <h2 id="order-history-heading" className="text-2xl md:text-3xl font-semibold text-gray-800 mb-6 border-b pb-4">Sipariş Geçmişi</h2>
          {orders.length === 0 ? (
            <p className="text-gray-600">Geçmiş siparişiniz bulunmamaktadır.</p>
          ) : (
            <div className="space-y-6">
              {orders.map((order) => (
                <div key={order.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex flex-wrap justify-between items-start mb-3">
                    <div>
                      <h3 className="text-lg font-semibold text-blue-600">Sipariş No: {order.id}</h3>
                      <p className="text-sm text-gray-500">Tarih: {new Date(order.date).toLocaleDateString('tr-TR')}</p>
                    </div>
                    <div className="mt-2 sm:mt-0">
                       <span className={`px-3 py-1 text-xs font-semibold rounded-full ${
                        order.status === 'Tamamlandı' ? 'bg-green-100 text-green-700' : // Assuming status is already Turkish from constants
                        order.status === 'Gönderildi' ? 'bg-blue-100 text-blue-700' :
                        'bg-yellow-100 text-yellow-700' // For 'İşleniyor' etc.
                      }`}>
                        {order.status} 
                      </span>
                    </div>
                  </div>
                  
                  <div className="mb-3">
                    <h4 className="text-sm font-medium text-gray-700 mb-1">Ürünler:</h4>
                    <ul className="list-disc list-inside text-sm text-gray-600 pl-4">
                      {order.items.map((item, index) => (
                        <li key={index}>
                          {item.productName} (x{item.quantity}) - ${item.pricePerItem.toFixed(2)} her biri
                        </li>
                      ))}
                    </ul>
                  </div>
                  <p className="text-right font-semibold text-gray-800 text-lg">
                    Toplam: ${order.totalAmount.toFixed(2)}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default UserProfilePage;