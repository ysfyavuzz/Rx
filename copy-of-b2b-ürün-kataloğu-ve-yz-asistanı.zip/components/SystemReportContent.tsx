import React from 'react';
import { INITIAL_PRODUCTS, DEMO_SALES_SUMMARY_DATA, DEMO_USER_PROFILE } from '../constants';

const SystemReportContent: React.FC = () => {
  const today = new Date().toLocaleDateString('tr-TR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  return (
    <div className="p-8 font-sans" style={{ fontFamily: 'Arial, sans-serif', color: '#333' }}>
      <header className="mb-10 text-center">
        <h1 className="text-4xl font-bold text-slate-800 mb-2">B2B Ürün Kataloğu ve YZ Asistanı</h1>
        <p className="text-lg text-gray-600">Sistem Durum Raporu ve Kullanım Kılavuzu</p>
        <p className="text-sm text-gray-500">Rapor Tarihi: {today}</p>
      </header>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-slate-700 border-b-2 border-slate-300 pb-2 mb-4">1. Uygulamaya Genel Bakış</h2>
        <p className="text-gray-700 leading-relaxed">
          Bu uygulama, B2B (Business-to-Business) senaryoları için tasarlanmış interaktif bir ürün kataloğudur.
          Kullanıcıların ürünlere göz atmasına, ürün detaylarını incelemesine, sanal bir sepete ürün eklemesine ve
          sipariş sürecini simüle etmesine olanak tanır. Ek olarak, Google Gemini Yapay Zeka (YZ) API'si entegrasyonu
          ile ürün açıklamalarını zenginleştirme, satış konuşmaları oluşturma ve satış verileri üzerinden trend analizleri
          yapma gibi gelişmiş özellikler sunar. Uygulama arayüzü tamamen Türkçe'dir.
        </p>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-slate-700 border-b-2 border-slate-300 pb-2 mb-4">2. Mevcut Durum ve Temel Fonksiyonlar</h2>
        <ul className="list-disc list-inside text-gray-700 leading-relaxed space-y-1 pl-4">
          <li><strong className="font-medium">Tamamen Türkçe Arayüz:</strong> Tüm metinler, butonlar ve mesajlar Türkçe'dir.</li>
          <li><strong className="font-medium">Ürün Kataloğu:</strong> {INITIAL_PRODUCTS.length} adet örnek ürün listelenmektedir.</li>
          <li><strong className="font-medium">Ürün Detay Sayfası:</strong> Her ürün için ayrıntılı bilgi, uzun açıklama ve (varsa) teknik özellikler sunulur.</li>
          <li><strong className="font-medium">Alışveriş Sepeti:</strong> Dinamik sepet yönetimi (ürün ekleme, miktar güncelleme, silme).</li>
          <li><strong className="font-medium">Sipariş Simülasyonu:</strong> Sepetteki ürünler için sipariş verme işlemi simüle edilir.</li>
          <li><strong className="font-medium">Kullanıcı Profili (Simüle Edilmiş):</strong> Örnek kullanıcı bilgileri ({DEMO_USER_PROFILE.name}) ve sipariş geçmişi gösterilir.</li>
          <li><strong className="font-medium">Raporlar Sayfası (Simüle Edilmiş Veriler):</strong>
            Toplam gelir (${DEMO_SALES_SUMMARY_DATA.totalRevenue.toLocaleString('tr-TR')}), toplam sipariş ({DEMO_SALES_SUMMARY_DATA.totalOrders})
            ve ortalama sipariş değeri (${DEMO_SALES_SUMMARY_DATA.averageOrderValue.toLocaleString('tr-TR')}) gibi temel metrikler sunulur.
            Ayrıca en çok satan ürünler listelenir.
          </li>
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-slate-700 border-b-2 border-slate-300 pb-2 mb-4">3. Yapay Zeka (YZ) Asistanı Özellikleri</h2>
        <div className="bg-amber-100 border-l-4 border-amber-500 text-amber-700 p-4 mb-4" role="alert">
          <p className="font-bold">Önemli Not:</p>
          <p>Tüm YZ özellikleri, geçerli bir <strong>GEMINI_API_KEY</strong> veya <strong>API_KEY</strong> ortam değişkeninin
          sisteminizde doğru bir şekilde yapılandırılmış olmasını gerektirir. Eğer API anahtarı eksik veya geçersizse,
          YZ özellikleri çalışmayacak ve ilgili butonlar kullanılamayacaktır veya hata mesajı görüntülenecektir.</p>
        </div>
        <ul className="list-disc list-inside text-gray-700 leading-relaxed space-y-2 pl-4">
          <li>
            <strong className="font-medium">Ürün Açıklaması Geliştirme:</strong>
            Ürün kartlarında veya ürün detay sayfasında bulunan "Açıklamayı Geliştir (YZ)" butonu ile seçili ürün için
            Google Gemini tarafından daha zengin ve çekici bir ürün açıklaması oluşturulur.
            Bu, özellikle B2B pazarlamasında ürünlerin faydalarını ve değer önerilerini vurgulamak için kullanışlıdır.
          </li>
          <li>
            <strong className="font-medium">Satış Konuşması Oluşturma:</strong>
            "Satış Konuşması Oluştur (YZ)" butonu, seçili ürün için potansiyel B2B müşterilere yönelik kısa,
            etkili ve ikna edici bir satış metni üretir. Bu metinler, satış ekiplerine veya pazarlama materyallerine
            hızlıca dahil edilebilir.
          </li>
          <li>
            <strong className="font-medium">Satış Trend Analizi:</strong>
            Raporlar sayfasındaki "YZ Trend Analizi Oluştur" butonu, uygulamada tanımlı simüle edilmiş satış verilerini
            (bkz: `SIMULATED_SALES_DATA_FOR_AI_PROMPT` sabiti) kullanarak Google Gemini'den bir satış trend analizi,
            temel çıkarımlar ve potansiyel görünüm talep eder. Bu analiz, karar verme süreçlerine destek olabilir.
            Sonuçlar bir modal pencerede gösterilir.
          </li>
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-slate-700 border-b-2 border-slate-300 pb-2 mb-4">4. Temel Kullanım Adımları</h2>
        <ol className="list-decimal list-inside text-gray-700 leading-relaxed space-y-1 pl-4">
          <li><strong>Ürünlere Göz Atma:</strong> Ana sayfada ("Ürünler" sekmesi) mevcut ürünleri listeleyebilirsiniz.</li>
          <li><strong>Detayları İnceleme:</strong> Bir ürünün adına veya resmine tıklayarak o ürünün detay sayfasına gidin. Burada uzun açıklamaları ve varsa teknik özellikleri bulabilirsiniz.</li>
          <li><strong>Sepete Ekleme:</strong> Ürün kartlarındaki veya ürün detay sayfasındaki "Sepete Ekle" butonu ile istediğiniz ürünleri sepetinize ekleyin. Aynı ürünü birden fazla kez ekleyebilirsiniz.</li>
          <li><strong>Sepeti Görüntüleme ve Yönetme:</strong>
            <ul>
              <li>Katalog sayfasındayken sağ üst köşede beliren sepet ikonuna tıklayarak sepeti açabilirsiniz.</li>
              <li>Sepet içinde ürün miktarlarını (henüz uygulanmadı, her ekleme 1 adet ekler), ürünleri silebilir ve toplam tutarı görebilirsiniz.</li>
            </ul>
          </li>
          <li><strong>Sipariş Verme (Simülasyon):</strong> Sepetinizdeyken "Siparişi Ver (Simülasyon)" butonuna tıklayarak sipariş işlemini taklit edin. Bu işlem sepeti boşaltır ve bir onay mesajı gösterir.</li>
          <li><strong>YZ Özelliklerini Kullanma:</strong>
            <ul>
              <li>API anahtarınızın doğru yapılandırıldığından emin olun.</li>
              <li>Ürün kartlarında veya detay sayfasında "Açıklamayı Geliştir (YZ)" veya "Satış Konuşması Oluştur (YZ)" butonlarına tıklayın.</li>
              <li>Sonuçlar bir modal pencerede gösterilecektir. YZ yanıt üretirken bir yükleme göstergesi belirebilir.</li>
            </ul>
          </li>
          <li><strong>Diğer Sayfalara Navigasyon:</strong> Üst menüdeki "Profilim" ve "Raporlar" linklerini kullanarak ilgili sayfalara geçiş yapın.</li>
          <li><strong>YZ Satış Analizi:</strong> "Raporlar" sayfasında, "YZ Trend Analizi Oluştur" butonuna tıklayarak analiz sonucunu bir modal pencerede görüntüleyin.</li>
        </ol>
      </section>

       <section className="mb-8">
        <h2 className="text-2xl font-semibold text-slate-700 border-b-2 border-slate-300 pb-2 mb-4">5. Teknik Özet</h2>
        <ul className="list-disc list-inside text-gray-700 leading-relaxed space-y-1 pl-4">
          <li><strong className="font-medium">Ana Teknolojiler:</strong> React (v19), TypeScript, Tailwind CSS.</li>
          <li><strong className="font-medium">YZ Entegrasyonu:</strong> Google Gemini API (`@google/genai` kütüphanesi). Model: `gemini-2.5-flash-preview-04-17`.</li>
          <li><strong className="font-medium">Veri Yönetimi:</strong> Tüm ürün, kullanıcı ve sipariş verileri şu anda istemci tarafında sabit olarak (`constants.ts` içinde) tutulmaktadır. Gerçek bir veritabanı bağlantısı bulunmamaktadır.</li>
          <li><strong className="font-medium">Arayüz:</strong> Tek Sayfa Uygulaması (SPA) yapısındadır. Sayfa geçişleri React state yönetimi ile sağlanır.</li>
           <li><strong className="font-medium">Geliştirme Ortamı:</strong> Bu raporun oluşturulduğu platformun sağladığı ortamda geliştirilmiştir. API anahtarı `process.env.API_KEY` veya `process.env.GEMINI_API_KEY` üzerinden beklenmektedir.</li>
        </ul>
      </section>

      <section>
        <h2 className="text-2xl font-semibold text-slate-700 border-b-2 border-slate-300 pb-2 mb-4">6. Notlar ve İpuçları</h2>
        <ul className="list-disc list-inside text-gray-700 leading-relaxed space-y-1 pl-4">
            <li>Uygulama şu an için bir simülasyon ve demo aracıdır. Gerçek B2B işlemleri için tasarlanmamıştır.</li>
            <li>YZ yanıtlarının kalitesi ve doğruluğu, kullanılan modele ve sağlanan istemlere (prompt) bağlıdır.</li>
            <li>Performans, özellikle YZ isteklerinde internet bağlantınıza ve Gemini API'nin o anki yoğunluğuna göre değişebilir.</li>
            <li>Geri bildirimleriniz ve özellik önerileriniz uygulamanın geliştirilmesi için değerlidir.</li>
        </ul>
      </section>

      <footer className="mt-12 pt-6 border-t-2 border-slate-300 text-center">
        <p className="text-sm text-gray-600">&copy; {new Date().getFullYear()} B2B Ürün Kataloğu ve YZ Asistanı. Tüm hakları saklıdır.</p>
      </footer>
    </div>
  );
};

export default SystemReportContent;
