import React from 'react';
import { Product } from '../types';
import LoadingSpinner from './LoadingSpinner';

interface ProductDetailPageProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  onGenerateDescription: (product: Product) => void;
  onGenerateSalesPitch: (product: Product) => void;
  isGeneratingAiContent: boolean;
  isApiKeyAvailable: boolean;
  onBack: () => void;
  isLoadingAiContentForThisProduct: boolean;
}

const ProductDetailPage: React.FC<ProductDetailPageProps> = ({
  product,
  onAddToCart,
  onGenerateDescription,
  onGenerateSalesPitch,
  isApiKeyAvailable,
  onBack,
  isLoadingAiContentForThisProduct,
}) => {
  return (
    <div className="bg-white p-6 md:p-8 rounded-xl shadow-2xl">
      <button
        onClick={onBack}
        className="mb-6 text-blue-600 hover:text-blue-800 transition-colors font-semibold flex items-center"
        aria-label="Ürün kataloğuna geri dön"
      >
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 mr-2">
          <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5" />
        </svg>
        Ürünlere Geri Dön
      </button>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <img 
            src={product.imageUrl} 
            alt={product.name} 
            className="w-full h-auto max-h-[500px] object-contain rounded-lg shadow-md border border-gray-200"
          />
        </div>
        <div className="flex flex-col">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-3">{product.name}</h1>
          <p className="text-sm text-gray-500 mb-3"><span className="font-medium">Kategori:</span> {product.category}</p>
          <p className="text-gray-700 mb-4 text-lg leading-relaxed">{product.longDescription || product.shortDescription}</p>
          
          {product.specifications && product.specifications.length > 0 && (
            <div className="mb-6">
              <h4 className="text-lg font-semibold text-gray-700 mb-2">Özellikler:</h4>
              <ul className="list-disc list-inside text-gray-600 space-y-1">
                {product.specifications.map((spec, index) => (
                  <li key={index}>
                    <span className="font-medium">{spec.name}:</span> {spec.value}
                  </li>
                ))}
              </ul>
            </div>
          )}

          <p className="text-3xl font-extrabold text-blue-700 mb-6">${product.price.toFixed(2)}</p>

          <div className="mt-auto space-y-3">
            <button
              onClick={() => onAddToCart(product)}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg transition duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-75 text-lg"
            >
              Sepete Ekle
            </button>

            {isApiKeyAvailable && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  onClick={() => onGenerateDescription(product)}
                  disabled={isLoadingAiContentForThisProduct}
                  className="w-full bg-green-500 hover:bg-green-600 text-white font-semibold py-3 px-4 rounded-lg transition duration-150 ease-in-out disabled:opacity-60 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-opacity-50"
                >
                  {isLoadingAiContentForThisProduct ? <LoadingSpinner /> : 'Açıklamayı Geliştir (YZ)'}
                </button>
                <button
                  onClick={() => onGenerateSalesPitch(product)}
                  disabled={isLoadingAiContentForThisProduct}
                  className="w-full bg-indigo-500 hover:bg-indigo-600 text-white font-semibold py-3 px-4 rounded-lg transition duration-150 ease-in-out disabled:opacity-60 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-opacity-50"
                >
                  {isLoadingAiContentForThisProduct ? <LoadingSpinner /> : 'Satış Konuşması Oluştur (YZ)'}
                </button>
              </div>
            )}
            {!isApiKeyAvailable && (
              <p className="text-sm text-amber-700 mt-2 text-center bg-amber-100 p-2 rounded-md">YZ özellikleri devre dışı. API Anahtarı yapılandırılmamış.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetailPage;