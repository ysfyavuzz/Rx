
export interface Product {
  id: string;
  name: string;
  shortDescription: string;
  longDescription: string; // Added for Product Detail Page
  price: number;
  imageUrl: string;
  category: string;
  specifications?: Array<{ name: string; value: string }>; // Added for Product Detail Page
}

export interface CartItem extends Product {
  quantity: number;
}

export enum ModalContentType {
  GEMINI_RESULT = 'GEMINI_RESULT',
  ORDER_CONFIRMATION = 'ORDER_CONFIRMATION',
  ERROR_MESSAGE = 'ERROR_MESSAGE',
  AI_SALES_ANALYSIS = 'AI_SALES_ANALYSIS'
}

// For User Profile Page
export interface UserProfileData {
  name: string;
  email: string;
  company: string;
  memberSince: string;
}

export interface OrderItem {
  productId: string;
  productName: string;
  quantity: number;
  pricePerItem: number;
}

export interface Order {
  id: string;
  date: string;
  items: OrderItem[];
  totalAmount: number;
  status: 'Tamamlandı' | 'İşleniyor' | 'Gönderildi'; // Updated to Turkish
}

// For Reports Page
export interface SalesSummaryData {
  totalRevenue: number;
  totalOrders: number;
  averageOrderValue: number;
  topSellingProducts: Array<{ id: string; name: string; unitsSold: number; revenue: number }>;
}