import React, { useState, useEffect, useCallback } from 'react';
import Header from './components/Header';
import ProductCard from './components/ProductCard';
import CartSidebar from './components/CartSidebar';
import Modal from './components/Modal';
import LoadingSpinner from './components/LoadingSpinner';
import ProductDetailPage from './components/ProductDetailPage'; // New
import UserProfilePage from './components/UserProfilePage'; // New
import ReportsPage from './components/ReportsPage'; // New
import { Product, CartItem, ModalContentType } from './types';
import { 
  INITIAL_PRODUCTS, 
  GEMINI_API_KEY_CHECK_MESSAGE, 
  GEMINI_API_ERROR_MESSAGE, 
  ORDER_SUCCESS_MESSAGE,
  DEMO_USER_PROFILE,
  DEMO_ORDER_HISTORY,
  DEMO_SALES_SUMMARY_DATA,
  SIMULATED_SALES_DATA_FOR_AI_PROMPT,
  AI_ANALYSIS_LOADING_MESSAGE,
  AI_ANALYSIS_ERROR_MESSAGE
} from './constants';
import { 
  generateProductDescription, 
  generateSalesPitch, 
  isGeminiApiKeyAvailable as checkGeminiKey,
  generateSalesTrendAnalysis // New
} from './services/geminiService';

type AppView = 'catalog' | 'productDetail' | 'userProfile' | 'reports';

const App: React.FC = () => {
  const [products] = useState<Product[]>(INITIAL_PRODUCTS);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalTitle, setModalTitle] = useState('');
  const [modalContent, setModalContent] = useState<React.ReactNode>('');
  const [modalType, setModalType] = useState<ModalContentType | null>(null);

  const [isGeneratingAiContent, setIsGeneratingAiContent] = useState(false);
  const [selectedProductForAi, setSelectedProductForAi] = useState<Product | null>(null);
  const [isApiKeyAvailable, setIsApiKeyAvailable] = useState<boolean>(false);

  // New state for page navigation
  const [currentView, setCurrentView] = useState<AppView>('catalog');
  const [selectedProductIdForDetail, setSelectedProductIdForDetail] = useState<string | null>(null);

  useEffect(() => {
    setIsApiKeyAvailable(checkGeminiKey());
  }, []);

  const handleOpenModal = useCallback((title: string, content: React.ReactNode, type: ModalContentType) => {
    setModalTitle(title);
    setModalContent(content);
    setModalType(type);
    setIsModalOpen(true);
  }, []);

  const handleAddToCart = useCallback((product: Product) => {
    setCartItems((prevItems) => {
      const existingItem = prevItems.find((item) => item.id === product.id);
      if (existingItem) {
        return prevItems.map((item) =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prevItems, { ...product, quantity: 1 }];
    });
    if (currentView !== 'productDetail') setIsCartOpen(true); 
  }, [currentView]);

  const handleRemoveFromCart = useCallback((productId: string) => {
    setCartItems((prevItems) => {
      const existingItem = prevItems.find((item) => item.id === productId);
      if (existingItem && existingItem.quantity > 1) {
        return prevItems.map((item) =>
          item.id === productId ? { ...item, quantity: item.quantity - 1 } : item
        );
      }
      return prevItems.filter((item) => item.id !== productId);
    });
  }, []);

  const handlePlaceOrder = useCallback(() => {
    handleOpenModal('Sipariş Onayı', ORDER_SUCCESS_MESSAGE, ModalContentType.ORDER_CONFIRMATION);
    setCartItems([]);
    setIsCartOpen(false);
  }, [handleOpenModal]);

  const handleNavigate = useCallback((view: AppView) => {
    setCurrentView(view);
    setSelectedProductIdForDetail(null); 
    window.scrollTo(0, 0); 
  }, []);

  const handleNavigateToDetail = useCallback((productId: string) => {
    setSelectedProductIdForDetail(productId);
    setCurrentView('productDetail');
    window.scrollTo(0, 0);
  }, []);
  
  const commonAiHandler = async (
    product: Product,
    aiFunction: (name: string, description: string) => Promise<string>,
    actionNameForTitle: string // This will be a pre-translated Turkish string
  ) => {
    if (!isApiKeyAvailable) {
      handleOpenModal('YZ Özelliği Devre Dışı', `Gemini API anahtarı yapılandırılmamış. ${actionNameForTitle} yapılamaz.`, ModalContentType.ERROR_MESSAGE);
      return;
    }
    setSelectedProductForAi(product);
    setIsGeneratingAiContent(true);
    
    const modalDisplayTitle = `YZ: ${product.name} için ${actionNameForTitle}`;

    if (currentView === 'catalog') {
         handleOpenModal(
            modalDisplayTitle,
            GEMINI_API_KEY_CHECK_MESSAGE, // This is already Turkish
            ModalContentType.GEMINI_RESULT
        );
    }

    try {
      const result = await aiFunction(product.name, product.longDescription || product.shortDescription);
      handleOpenModal(modalDisplayTitle, result, ModalContentType.GEMINI_RESULT);
    } catch (error) {
      console.error(error);
      const errorMessage = error instanceof Error ? error.message : GEMINI_API_ERROR_MESSAGE; // Error messages from constants are Turkish
      handleOpenModal('YZ Hatası', errorMessage, ModalContentType.ERROR_MESSAGE);
    } finally {
      setIsGeneratingAiContent(false);
      setSelectedProductForAi(null);
    }
  };

  const handleGenerateDescription = useCallback(
    (product: Product) => commonAiHandler(product, generateProductDescription, 'Açıklama Geliştirme'),
    [handleOpenModal, isApiKeyAvailable, commonAiHandler, currentView] // commonAiHandler added as dependency
  );

  const handleGenerateSalesPitch = useCallback(
    (product: Product) => commonAiHandler(product, generateSalesPitch, 'Satış Konuşması'),
    [handleOpenModal, isApiKeyAvailable, commonAiHandler, currentView] // commonAiHandler added as dependency
  );
  
  const handleGenerateSalesAnalysis = useCallback(async () => {
    if (!isApiKeyAvailable) {
      handleOpenModal('YZ Özelliği Devre Dışı', 'Gemini API anahtarı yapılandırılmamış. Satış analizi oluşturulamaz.', ModalContentType.ERROR_MESSAGE);
      return;
    }
    setIsGeneratingAiContent(true);
    handleOpenModal(
        'YZ Satış Trend Analizi', 
        AI_ANALYSIS_LOADING_MESSAGE, // Already Turkish
        ModalContentType.AI_SALES_ANALYSIS
    );

    try {
      const analysis = await generateSalesTrendAnalysis(SIMULATED_SALES_DATA_FOR_AI_PROMPT); // Prompt is Turkish
      handleOpenModal('YZ Satış Trend Analizi', analysis, ModalContentType.AI_SALES_ANALYSIS);
    } catch (error) {
      console.error(error);
      const errorMessage = error instanceof Error ? error.message : AI_ANALYSIS_ERROR_MESSAGE; // Error messages from constants are Turkish
      handleOpenModal('YZ Hatası', errorMessage, ModalContentType.ERROR_MESSAGE);
    } finally {
      setIsGeneratingAiContent(false);
    }
  }, [handleOpenModal, isApiKeyAvailable]);

  const selectedProduct = products.find(p => p.id === selectedProductIdForDetail);

  const renderView = () => {
    switch (currentView) {
      case 'productDetail':
        if (selectedProduct) {
          return (
            <ProductDetailPage
              product={selectedProduct}
              onAddToCart={handleAddToCart}
              onGenerateDescription={handleGenerateDescription}
              onGenerateSalesPitch={handleGenerateSalesPitch}
              isGeneratingAiContent={isGeneratingAiContent && selectedProductForAi?.id === selectedProduct.id}
              isApiKeyAvailable={isApiKeyAvailable}
              onBack={() => handleNavigate('catalog')}
              isLoadingAiContentForThisProduct={isGeneratingAiContent && selectedProductForAi?.id === selectedProduct.id}
            />
          );
        }
        setCurrentView('catalog'); 
        return null; 
      case 'userProfile':
        return (
          <UserProfilePage 
            user={DEMO_USER_PROFILE} 
            orders={DEMO_ORDER_HISTORY} 
          />
        );
      case 'reports':
        return (
          <ReportsPage 
            summaryData={DEMO_SALES_SUMMARY_DATA}
            onGenerateAiAnalysis={handleGenerateSalesAnalysis}
            isGeneratingAiAnalysis={isGeneratingAiContent && modalType === ModalContentType.AI_SALES_ANALYSIS}
            isApiKeyAvailable={isApiKeyAvailable}
          />
        );
      case 'catalog':
      default:
        return (
          <>
            <h2 className="text-3xl font-semibold text-gray-700 mb-8">Ürünlerimiz</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {products.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAddToCart={handleAddToCart}
                  onGenerateDescription={handleGenerateDescription}
                  onGenerateSalesPitch={handleGenerateSalesPitch}
                  onNavigateToDetail={handleNavigateToDetail}
                  isGenerating={isGeneratingAiContent && selectedProductForAi?.id === product.id}
                  isApiKeyAvailable={isApiKeyAvailable}
                />
              ))}
            </div>
          </>
        );
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header onNavigate={handleNavigate} />
      
      {currentView === 'catalog' && (
        <button
          onClick={() => setIsCartOpen(true)}
          className="fixed top-24 right-6 bg-blue-600 text-white p-3 rounded-full shadow-lg z-30 hover:bg-blue-700 transition-colors"
          aria-label="Sepeti aç"
        >
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
            <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 0 0-3 3h15.75m-12.75-3h11.218c1.121-2.3 2.1-4.684 2.924-7.138a60.114 60.114 0 0 0-16.536-1.84M7.5 14.25 5.106 5.272M6 20.25a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Zm12.75 0a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Z" />
          </svg>
          {cartItems.reduce((acc, item) => acc + item.quantity, 0) > 0 && (
            <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full px-2 py-0.5">
              {cartItems.reduce((acc, item) => acc + item.quantity, 0)}
            </span>
          )}
        </button>
      )}

      <main className="flex-grow container mx-auto px-4 py-8">
        {isGeneratingAiContent && selectedProductForAi && currentView === 'catalog' && 
         !(isModalOpen && (modalType === ModalContentType.GEMINI_RESULT || modalType === ModalContentType.AI_SALES_ANALYSIS)) && // Hide if a modal for AI result is already showing
          (
          <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-[60] bg-white p-8 rounded-lg shadow-xl flex flex-col items-center">
            <LoadingSpinner />
            <p className="mt-4 text-lg text-gray-700">YZ, {selectedProductForAi.name} için düşünüyor...</p>
          </div>
        )}
        {renderView()}
      </main>

      <CartSidebar
        cartItems={cartItems}
        onRemoveFromCart={handleRemoveFromCart}
        onPlaceOrder={handlePlaceOrder}
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
      />

      <Modal
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)}
        title={modalTitle}
      >
        {/* Show spinner in modal only if it's the initial AI check message */}
        {isGeneratingAiContent && (modalType === ModalContentType.GEMINI_RESULT || modalType === ModalContentType.AI_SALES_ANALYSIS) && modalContent === GEMINI_API_KEY_CHECK_MESSAGE && <LoadingSpinner />}
        {modalContent}
      </Modal>
      
      <footer className="bg-slate-800 text-gray-300 text-center p-6 mt-auto">
        <p>&copy; {new Date().getFullYear()} B2B Ürün Paketi. Tüm hakları saklıdır.</p>
        <p className="text-sm mt-1">React, Tailwind CSS ve Gemini YZ ile güçlendirilmiştir.</p>
      </footer>
    </div>
  );
};

export default App;