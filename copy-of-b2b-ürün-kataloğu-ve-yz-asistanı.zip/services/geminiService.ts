
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { GEMINI_API_ERROR_MESSAGE, AI_ANALYSIS_ERROR_MESSAGE } from '../constants';

const API_KEY = process.env.GEMINI_API_KEY || process.env.API_KEY; 

let ai: GoogleGenAI | null = null;
if (API_KEY) {
  ai = new GoogleGenAI({ apiKey: API_KEY });
} else {
  console.warn("Gemini API anahtarı bulunamadı. YZ özellikleri devre dışı bırakılacak. Lütfen GEMINI_API_KEY veya API_KEY ortam değişkenini ayarlayın.");
}

const TEXT_MODEL = 'gemini-2.5-flash-preview-04-17';

export const isGeminiApiKeyAvailable = (): boolean => !!API_KEY;


export const generateProductDescription = async (productName: string, currentDescription: string): Promise<string> => {
  if (!ai) {
    throw new Error("Gemini API istemcisi başlatılmadı. API anahtarı eksik olabilir.");
  }
  try {
    const prompt = `"${productName}" adlı bir ürün için ilgi çekici ve profesyonel bir B2B ürün açıklaması oluşturun.
    Mevcut kısa açıklaması: "${currentDescription}".
    Bunu genişletin, temel özelliklerine, faydalarına ve işletmeler için değer önerisine odaklanın.
    Bir ürün kataloğu için uygun, yaklaşık 3-4 cümlelik, öz ve etkili tutun.
    Yanıtınızda markdown formatı kullanmayın. Yanıtı Türkçe verin.`;

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: TEXT_MODEL,
      contents: prompt,
    });
    return response.text.trim();
  } catch (error) {
    console.error("Ürün açıklaması oluşturulurken hata oluştu:", error);
    throw new Error(GEMINI_API_ERROR_MESSAGE);
  }
};

export const generateSalesPitch = async (productName: string, productDescription: string): Promise<string> => {
  if (!ai) {
    throw new Error("Gemini API istemcisi başlatılmadı. API anahtarı eksik olabilir.");
  }
  try {
    const prompt = `"${productName}" adlı bir ürün için kısa, ikna edici ve profesyonel bir B2B satış konuşması oluşturun.
    Ürün şu şekilde tanımlanmaktadır: "${productDescription}".
    Potansiyel iş müşterileri için benzersiz satış noktalarını ve temel faydalarını vurgulayın.
    Satış konuşması ilgi çekici olmalı ve daha fazla araştırma yapmaya teşvik etmelidir. 2-3 özlü cümleyi hedefleyin.
    Yanıtınızda markdown formatı kullanmayın. Yanıtı Türkçe verin.`;

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: TEXT_MODEL,
      contents: prompt,
    });
    return response.text.trim();
  } catch (error) {
    console.error("Satış konuşması oluşturulurken hata oluştu:", error);
    throw new Error(GEMINI_API_ERROR_MESSAGE);
  }
};

export const generateSalesTrendAnalysis = async (salesDataSummary: string): Promise<string> => {
  if (!ai) {
    throw new Error("Gemini API istemcisi başlatılmadı. API anahtarı eksik olabilir.");
  }
  try {
    const prompt = `Bir B2B satış analisti olarak aşağıdaki satış verileri özetini analiz edin ve kısa bir trend analizi, temel çıkarımlar ve potansiyel görünüm sağlayın.
Satış Verileri Özeti:
${salesDataSummary}

Analiziniz şu şekilde olmalıdır:
- Profesyonel ve öz.
- B2B bağlamında eyleme geçirilebilir içgörülere odaklanmış.
- Temel eğilimleri, büyüme alanlarını veya dikkat edilmesi gereken alanları vurgulayın.
- Kısa bir görünüm veya öneriler sunun.
Yanıtınızda markdown formatı kullanmayın. Yanıtınızı net paragraflar halinde Türkçe olarak yapılandırın.`;

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: TEXT_MODEL,
      contents: prompt,
    });
    return response.text.trim();
  } catch (error) {
    console.error("Satış trend analizi oluşturulurken hata oluştu:", error);
    throw new Error(AI_ANALYSIS_ERROR_MESSAGE);
  }
};