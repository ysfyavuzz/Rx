
import { Product, UserProfileData, Order, SalesSummaryData } from './types';

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod_1',
    name: 'Kurumsal Bulut Depolama V2',
    shortDescription: 'Ölçeklenebilir, güvenli ve yüksek performanslı bulut depolama çözümü.',
    longDescription: 'Kurumsal Bulut Depolama V2 çözümümüz, iş açısından kritik verileriniz için benzersiz ölçeklenebilirlik ve güvenlik sunar. Otomatik yedeklemeler, coğrafi yedeklilik ve %99,999 çalışma süresi SLA\'sı gibi özelliklerle modern veri altyapısının bel kemiğidir. Mevcut kurumsal uygulamalarla sorunsuz bir şekilde entegre olur.',
    price: 499.99,
    imageUrl: 'https://picsum.photos/seed/prod1/400/300',
    category: 'Bulut Hizmetleri',
    specifications: [
      { name: 'Depolama Katmanları', value: 'Hot, Cool, Archive' },
      { name: 'Güvenlik', value: 'Uçtan uca şifreleme, IAM kontrolleri' },
      { name: 'Uyumluluk', value: 'ISO 27001, SOC 2, HIPAA' }
    ]
  },
  {
    id: 'prod_2',
    name: 'Yapay Zeka Destekli CRM Platformu',
    shortDescription: 'Akıllı CRM ve tahminsel analizlerle satışlarınızı artırın.',
    longDescription: 'Yapay Zeka Destekli CRM Platformumuzla müşteri ilişkilerinizi dönüştürün. Potansiyel müşteri puanlaması için tahminsel analizlerden yararlanın, satış iş akışlarını otomatikleştirin ve müşteri davranışlarına ilişkin derinlemesine içgörüler kazanın. Satış, pazarlama ve servis modüllerini tek bir birleşik platformda içerir.',
    price: 799.00,
    imageUrl: 'https://picsum.photos/seed/prod2/400/300',
    category: 'Yazılım',
    specifications: [
      { name: 'Anahtar Modüller', value: 'Satış Otomasyonu, Pazarlama Kampanyaları, Müşteri Hizmetleri Masası' },
      { name: 'YZ Özellikleri', value: 'Tahmini Müşteri Adayı Puanlaması, Duygu Analizi, Müşteri Kaybı Tahmini' },
      { name: 'Entegrasyonlar', value: 'Outlook, GSuite, Slack, Zapier' }
    ]
  },
  {
    id: 'prod_3',
    name: 'Endüstriyel Otomasyon Robotu X1',
    shortDescription: 'Üretim ve lojistik için ağır hizmet tipi robotik kol.',
    longDescription: 'Endüstriyel Otomasyon Robotu X1, zorlu ortamlarda hassasiyet ve dayanıklılık için tasarlanmıştır. 25 kg taşıma kapasitesi ve 1,5 m erişim mesafesi ile montaj, al-bırak ve kaynak gibi görevler için idealdir. Sezgisel görsel arayüzümüzle veya API aracılığıyla kolayca programlayın.',
    price: 12500.00,
    imageUrl: 'https://picsum.photos/seed/prod3/400/300',
    category: 'Makine Ekipmanları',
    specifications: [
      { name: 'Taşıma Kapasitesi', value: '25 kg' },
      { name: 'Erişim Mesafesi', value: '1.5 metre' },
      { name: 'Serbestlik Derecesi', value: '6' }
    ]
  },
  {
    id: 'prod_4',
    name: 'Siber Güvenlik Paketi Pro',
    shortDescription: 'Gelişen siber tehditlere karşı kapsamlı koruma.',
    longDescription: 'Siber Güvenlik Paketi Pro çözümümüz, işletmeniz için çok katmanlı savunma sağlar. Yeni nesil uç nokta koruması, ağ tehdidi tespiti, e-posta güvenliği ve güvenlik açığı yönetimini içerir. Gerçek zamanlı tehdit istihbaratı ve otomatik yanıt yetenekleriyle saldırganların bir adım önünde olun.',
    price: 350.50,
    imageUrl: 'https://picsum.photos/seed/prod4/400/300',
    category: 'Güvenlik',
  },
  {
    id: 'prod_5',
    name: 'Lojistik ve Filo Yönetimi SaaS',
    shortDescription: 'Gerçek zamanlı takip ve yönetim ile tedarik zincirini optimize edin.',
    longDescription: 'Kapsamlı SaaS platformumuzla lojistik operasyonlarınızı kolaylaştırın. Gerçek zamanlı GPS takibi, rota optimizasyonu, yakıt yönetimi, bakım planlaması ve sürücü performans analitiği gibi özellikler içerir. Tüm filonuzda maliyetleri azaltın ve verimliliği artırın.',
    price: 299.00,
    imageUrl: 'https://picsum.photos/seed/prod5/400/300',
    category: 'Yazılım',
  },
  {
    id: 'prod_6',
    name: 'Çevre Dostu Ambalaj Çözümleri',
    shortDescription: 'Çevreye duyarlı işletmeler için sürdürülebilir ambalaj.',
    longDescription: 'Geri dönüştürülmüş, biyolojik olarak parçalanabilir veya kompostlanabilir malzemelerden üretilen çevre dostu ambalaj çözümlerimizle müşterilerinize sürdürülebilir seçenekler sunun. Ürünlerimiz, kalite veya dayanıklılıktan ödün vermeden çevresel etkiyi azaltmaya yardımcı olur. Özel markalama seçenekleri mevcuttur.',
    price: 150.00, 
    imageUrl: 'https://picsum.photos/seed/prod6/400/300',
    category: 'Malzemeler',
  }
];

export const GEMINI_API_KEY_CHECK_MESSAGE = "YZ özellikleri kullanılmaya çalışılıyor. Not: Bu özelliklerin çalışması için geçerli bir GEMINI_API_KEY ortam değişkeninin yapılandırılmış olması gerekir. YZ yanıtları üretilmiyorsa, lütfen API anahtarının ortamınızda doğru şekilde ayarlandığından emin olun.";
export const GEMINI_API_ERROR_MESSAGE = "YZ'den yanıt alınamadı. Lütfen API anahtarınızın geçerli olduğundan ve yeterli kotanızın bulunduğundan emin olun veya daha sonra tekrar deneyin.";
export const ORDER_SUCCESS_MESSAGE = "Siparişiniz başarıyla verildi! (Bu bir simülasyondur).";
export const AI_ANALYSIS_LOADING_MESSAGE = "YZ satış verilerini analiz ediyor. Lütfen bekleyin...";
export const AI_ANALYSIS_ERROR_MESSAGE = "YZ'den satış analizi oluşturulamadı. Lütfen daha sonra tekrar deneyin.";

export const DEMO_USER_PROFILE: UserProfileData = {
  name: 'Ali Veli',
  email: 'ali.veli@ornekb2b.com',
  company: 'İnovatek Çözümleri Ltd. Şti.',
  memberSince: '2022-01-15',
};

export const DEMO_ORDER_HISTORY: Order[] = [
  {
    id: 'SIP-2023-001',
    date: '2023-10-25',
    items: [
      { productId: 'prod_1', productName: 'Kurumsal Bulut Depolama V2', quantity: 1, pricePerItem: 499.99 },
      { productId: 'prod_4', productName: 'Siber Güvenlik Paketi Pro', quantity: 2, pricePerItem: 350.50 },
    ],
    totalAmount: 1201.99,
    status: 'Tamamlandı',
  },
  {
    id: 'SIP-2023-002',
    date: '2023-11-10',
    items: [
      { productId: 'prod_2', productName: 'Yapay Zeka Destekli CRM Platformu', quantity: 1, pricePerItem: 799.00 },
    ],
    totalAmount: 799.00,
    status: 'Gönderildi',
  },
  {
    id: 'SIP-2024-001',
    date: '2024-01-05',
    items: [
      { productId: 'prod_5', productName: 'Lojistik ve Filo Yönetimi SaaS', quantity: 1, pricePerItem: 299.00 },
      { productId: 'prod_6', productName: 'Çevre Dostu Ambalaj Çözümleri', quantity: 10, pricePerItem: 15.00 }, // Örnek için toplu fiyat varsayımı
    ],
    totalAmount: 449.00,
    status: 'İşleniyor',
  },
];

export const DEMO_SALES_SUMMARY_DATA: SalesSummaryData = {
  totalRevenue: 156750.75,
  totalOrders: 215,
  averageOrderValue: 729.07,
  topSellingProducts: [
    { id: 'prod_2', name: 'Yapay Zeka Destekli CRM Platformu', unitsSold: 85, revenue: 67915.00 },
    { id: 'prod_1', name: 'Kurumsal Bulut Depolama V2', unitsSold: 60, revenue: 29999.40 },
    { id: 'prod_4', name: 'Siber Güvenlik Paketi Pro', unitsSold: 70, revenue: 24535.00 },
  ],
};

// Satış trend analizi için Gemini'ye gönderilecek veriler.
// Bu istemin İngilizce kalması, AI'nin tutarlı ve beklenen formatta yanıt vermesine yardımcı olabilir.
// Eğer AI'nin Türkçe analiz yapması isteniyorsa, bu istem de dikkatlice Türkçe'ye çevrilmelidir.
// Şimdilik AI'nin temel veri işleme mantığını korumak adına İngilizce bırakılmıştır.
// Ancak, kullanıcı deneyimi tamamen Türkçe olacaksa, bu istemin de çevrilmesi daha uygun olur.
// Şimdilik, Türkçe AI yanıtları için promptları da Türkçe'ye çevireceğiz.
export const SIMULATED_SALES_DATA_FOR_AI_PROMPT = `
Çeyreklik Satış Performansı:
- 2023 4. Çeyrek: Toplam Gelir 55.000 TL, 75 sipariş. En Çok Satan Ürün: Yapay Zeka Destekli CRM Platformu.
- 2024 1. Çeyrek: Toplam Gelir 62.000 TL, 85 sipariş. En Çok Satan Ürün: Yapay Zeka Destekli CRM Platformu, Siber Güvenlik Paketi Pro'da önemli büyüme.
- 2024 2. Çeyrek (Tahmini): Gelir 70.000 TL, 95 sipariş. Lojistik SaaS'ta beklenen büyüme.

Anahtar Ürün Performansı:
- Yapay Zeka Destekli CRM: Sürekli yüksek talep.
- Kurumsal Bulut Depolama: İstikrarlı satışlar.
- Siber Güvenlik Paketi: 2024 1. Çeyrekte artan talep.
- Lojistik SaaS: Popülerlik kazanıyor.
`;