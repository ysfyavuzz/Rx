import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { loginSchema, insertUserSchema, insertProductSchema, insertOrderSchema, excelProductSchema } from "@shared/schema";
import multer from "multer";
import * as XLSX from "xlsx";
import nodemailer from "nodemailer";

// Configure multer for file uploads
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

// Email configuration
const emailTransporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || "smtp.gmail.com",
  port: parseInt(process.env.SMTP_PORT || "587"),
  secure: false,
  auth: {
    user: process.env.SMTP_USER || process.env.EMAIL_USER || "test@example.com",
    pass: process.env.SMTP_PASS || process.env.EMAIL_PASS || "testpass123"
  }
});

// Session management
const sessions = new Map<string, { userId: number; expiresAt: Date }>();

function generateSessionId(): string {
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
}

function authenticateUser(req: any): number | null {
  const sessionId = req.headers.authorization?.replace('Bearer ', '');
  if (!sessionId) return null;
  
  const session = sessions.get(sessionId);
  if (!session || session.expiresAt < new Date()) {
    sessions.delete(sessionId);
    return null;
  }
  
  return session.userId;
}

async function requireAuth(req: any, res: any, next: any) {
  const userId = authenticateUser(req);
  if (!userId) {
    return res.status(401).json({ message: "Authentication required" });
  }
  (req as any).userId = userId;
  next();
}

async function requireAdmin(req: any, res: any, next: any) {
  const userId = authenticateUser(req);
  if (!userId) {
    return res.status(401).json({ message: "Authentication required" });
  }
  
  const user = await storage.getUser(userId);
  if (!user || user.role !== "admin") {
    return res.status(403).json({ message: "Admin access required" });
  }
  
  (req as any).userId = userId;
  (req as any).user = user;
  next();
}

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Authentication routes
  app.post("/api/login", async (req, res) => {
    try {
      const credentials = loginSchema.parse(req.body);
      const user = await storage.getUserByUsername(credentials.username);
      
      if (!user || user.password !== credentials.password || !user.isActive) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      const sessionId = generateSessionId();
      const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours
      sessions.set(sessionId, { userId: user.id, expiresAt });
      
      res.json({ 
        token: sessionId, 
        user: { 
          id: user.id, 
          username: user.username, 
          email: user.email, 
          role: user.role 
        } 
      });
    } catch (error) {
      res.status(400).json({ message: "Invalid request data" });
    }
  });

  app.post("/api/logout", requireAuth, (req, res) => {
    const sessionId = req.headers.authorization?.replace('Bearer ', '');
    if (sessionId) {
      sessions.delete(sessionId);
    }
    res.json({ message: "Logged out successfully" });
  });

  app.get("/api/me", requireAuth, async (req, res) => {
    const user = await storage.getUser((req as any).userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    res.json({ 
      id: user.id, 
      username: user.username, 
      email: user.email, 
      role: user.role 
    });
  });

  // User management (admin only)
  app.post("/api/users", requireAdmin, async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if username or email already exists
      const existingUser = await storage.getUserByUsername(userData.username) || 
                          await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "Username or email already exists" });
      }
      
      const user = await storage.createUser(userData);
      res.status(201).json({ 
        id: user.id, 
        username: user.username, 
        email: user.email, 
        role: user.role 
      });
    } catch (error) {
      res.status(400).json({ message: "Invalid user data" });
    }
  });

  app.get("/api/users", requireAdmin, async (req, res) => {
    const users = await storage.getUser(0); // Get all users for admin
    // Since we don't have a getUsers method, we'll simulate it
    res.json([]);
  });

  // Product routes
  app.get("/api/products", async (req, res) => {
    try {
      const { search, category } = req.query;
      let products;
      
      if (search) {
        products = await storage.searchProducts(search as string);
      } else if (category) {
        products = await storage.getProductsByCategory(category as string);
      } else {
        products = await storage.getProducts();
      }
      
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  app.get("/api/products/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const product = await storage.getProduct(id);
      
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      res.json(product);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  app.post("/api/products", requireAdmin, upload.single('image'), async (req, res) => {
    try {
      const productData = insertProductSchema.parse({
        ...req.body,
        price: parseInt(req.body.price),
        stock: parseInt(req.body.stock)
      });
      
      // Handle image upload
      if (req.file) {
        // In a real application, you would upload to a cloud storage service
        // For now, we'll just store a placeholder URL
        productData.imageUrl = `/uploads/${req.file.originalname}`;
      }
      
      const product = await storage.createProduct(productData);
      res.status(201).json(product);
    } catch (error) {
      res.status(400).json({ message: "Invalid product data" });
    }
  });

  app.put("/api/products/:id", requireAdmin, upload.single('image'), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = {
        ...req.body,
        price: req.body.price ? parseInt(req.body.price) : undefined,
        stock: req.body.stock ? parseInt(req.body.stock) : undefined
      };
      
      // Handle image upload
      if (req.file) {
        updates.imageUrl = `/uploads/${req.file.originalname}`;
      }
      
      const product = await storage.updateProduct(id, updates);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      res.json(product);
    } catch (error) {
      res.status(400).json({ message: "Invalid product data" });
    }
  });

  app.delete("/api/products/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteProduct(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      res.json({ message: "Product deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete product" });
    }
  });

  // Excel upload for products
  app.post("/api/products/excel", requireAdmin, upload.single('excel'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "Excel file is required" });
      }
      
      const workbook = XLSX.read(req.file.buffer, { type: 'buffer' });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet);
      
      const products = [];
      const errors = [];
      
      for (let i = 0; i < jsonData.length; i++) {
        try {
          const row = jsonData[i] as any;
          const productData = excelProductSchema.parse({
            name: row['Ürün Adı'] || row['Product Name'] || row.name,
            description: row['Açıklama'] || row['Description'] || row.description,
            price: Math.round((parseFloat(row['Fiyat'] || row['Price'] || row.price) || 0) * 100), // Convert to cents
            stock: parseInt(row['Stok'] || row['Stock'] || row.stock) || 0,
            category: row['Kategori'] || row['Category'] || row.category || 'Genel'
          });
          products.push(productData);
        } catch (error) {
          errors.push(`Row ${i + 2}: ${error instanceof Error ? error.message : 'Invalid data'}`);
        }
      }
      
      if (products.length === 0) {
        return res.status(400).json({ message: "No valid products found in Excel file", errors });
      }
      
      const createdProducts = await storage.bulkCreateProducts(products);
      res.json({ 
        message: `Successfully imported ${createdProducts.length} products`, 
        products: createdProducts,
        errors 
      });
    } catch (error) {
      res.status(400).json({ message: "Failed to process Excel file" });
    }
  });

  // Order routes
  app.get("/api/orders", requireAuth, async (req, res) => {
    try {
      const user = await storage.getUser((req as any).userId);
      let orders;
      
      if (user?.role === "admin") {
        orders = await storage.getOrders();
      } else {
        orders = await storage.getOrdersByUser((req as any).userId);
      }
      
      res.json(orders);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  app.post("/api/orders", requireAuth, async (req, res) => {
    try {
      const orderData = insertOrderSchema.parse(req.body);
      orderData.userId = (req as any).userId;
      
      const order = await storage.createOrder(orderData);
      
      // Send email notification
      try {
        const user = await storage.getUser((req as any).userId);
        const cartItems = JSON.parse(orderData.items);
        
        const emailHtml = `
          <h2>Yeni B2B Sipariş</h2>
          <p><strong>Müşteri:</strong> ${user?.username} (${user?.email})</p>
          <p><strong>Sipariş No:</strong> ${order.id}</p>
          <p><strong>Toplam Tutar:</strong> ₺${(orderData.totalAmount / 100).toFixed(2)}</p>
          
          <h3>Sipariş Detayları:</h3>
          <table border="1" style="border-collapse: collapse; width: 100%;">
            <thead>
              <tr>
                <th>Ürün</th>
                <th>Adet</th>
                <th>Fiyat</th>
                <th>Toplam</th>
              </tr>
            </thead>
            <tbody>
              ${cartItems.map((item: any) => `
                <tr>
                  <td>${item.name}</td>
                  <td>${item.quantity}</td>
                  <td>₺${(item.price / 100).toFixed(2)}</td>
                  <td>₺${((item.price * item.quantity) / 100).toFixed(2)}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        `;
        
        await emailTransporter.sendMail({
          from: process.env.SMTP_USER || process.env.EMAIL_USER || "noreply@company.com",
          to: process.env.ORDER_EMAIL || "orders@company.com",
          subject: `Yeni B2B Sipariş #${order.id}`,
          html: emailHtml
        });
      } catch (emailError) {
        console.error('Failed to send order email:', emailError);
        // Don't fail the order creation if email fails
      }
      
      res.status(201).json(order);
    } catch (error) {
      res.status(400).json({ message: "Invalid order data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
