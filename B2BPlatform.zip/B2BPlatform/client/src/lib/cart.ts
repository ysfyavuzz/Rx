import { CartItem } from "@shared/schema";

export interface CartState {
  items: CartItem[];
  totalItems: number;
  totalAmount: number;
}

class CartManager {
  private state: CartState = {
    items: [],
    totalItems: 0,
    totalAmount: 0
  };

  private listeners: ((state: CartState) => void)[] = [];

  constructor() {
    // Load cart from localStorage on initialization
    const savedCart = localStorage.getItem('cart');
    if (savedCart) {
      try {
        this.state.items = JSON.parse(savedCart);
        this.updateTotals();
      } catch (error) {
        console.error('Failed to load cart from localStorage:', error);
        this.clearCart();
      }
    }
  }

  addItem(productId: number, name: string, price: number, quantity: number, imageUrl?: string) {
    const existingItemIndex = this.state.items.findIndex(item => item.productId === productId);
    
    if (existingItemIndex >= 0) {
      // Update existing item quantity
      this.state.items[existingItemIndex].quantity += quantity;
    } else {
      // Add new item
      this.state.items.push({
        productId,
        name,
        price,
        quantity,
        imageUrl
      });
    }
    
    this.updateTotals();
    this.saveToStorage();
    this.notifyListeners();
  }

  updateItemQuantity(productId: number, quantity: number) {
    if (quantity <= 0) {
      this.removeItem(productId);
      return;
    }

    const itemIndex = this.state.items.findIndex(item => item.productId === productId);
    if (itemIndex >= 0) {
      this.state.items[itemIndex].quantity = quantity;
      this.updateTotals();
      this.saveToStorage();
      this.notifyListeners();
    }
  }

  removeItem(productId: number) {
    this.state.items = this.state.items.filter(item => item.productId !== productId);
    this.updateTotals();
    this.saveToStorage();
    this.notifyListeners();
  }

  clearCart() {
    this.state.items = [];
    this.updateTotals();
    this.saveToStorage();
    this.notifyListeners();
  }

  getState(): CartState {
    return { ...this.state };
  }

  private updateTotals() {
    this.state.totalItems = this.state.items.reduce((sum, item) => sum + item.quantity, 0);
    this.state.totalAmount = this.state.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  }

  private saveToStorage() {
    try {
      localStorage.setItem('cart', JSON.stringify(this.state.items));
    } catch (error) {
      console.error('Failed to save cart to localStorage:', error);
    }
  }

  subscribe(callback: (state: CartState) => void): () => void {
    this.listeners.push(callback);
    
    // Return unsubscribe function
    return () => {
      const index = this.listeners.indexOf(callback);
      if (index > -1) {
        this.listeners.splice(index, 1);
      }
    };
  }

  private notifyListeners() {
    this.listeners.forEach(callback => callback(this.getState()));
  }
}

export const cartManager = new CartManager();
