import { User } from "@shared/schema";

export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
}

class AuthManager {
  private state: AuthState = {
    user: null,
    token: null,
    isAuthenticated: false
  };

  private listeners: ((state: AuthState) => void)[] = [];

  constructor() {
    // Load token from localStorage on initialization
    const token = localStorage.getItem('authToken');
    if (token) {
      this.state.token = token;
      this.verifyToken();
    }
  }

  private async verifyToken() {
    if (!this.state.token) return;

    try {
      const response = await fetch('/api/me', {
        headers: {
          'Authorization': `Bearer ${this.state.token}`
        }
      });

      if (response.ok) {
        const user = await response.json();
        this.state.user = user;
        this.state.isAuthenticated = true;
        this.notifyListeners();
      } else {
        this.logout();
      }
    } catch (error) {
      this.logout();
    }
  }

  async login(username: string, password: string): Promise<{ success: boolean; error?: string }> {
    try {
      const response = await fetch('/api/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
      });

      if (response.ok) {
        const data = await response.json();
        this.state.token = data.token;
        this.state.user = data.user;
        this.state.isAuthenticated = true;
        
        localStorage.setItem('authToken', data.token);
        this.notifyListeners();
        
        return { success: true };
      } else {
        const errorData = await response.json();
        return { success: false, error: errorData.message || 'Login failed' };
      }
    } catch (error) {
      return { success: false, error: 'Network error occurred' };
    }
  }

  async logout() {
    if (this.state.token) {
      try {
        await fetch('/api/logout', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${this.state.token}`
          }
        });
      } catch (error) {
        console.error('Logout request failed:', error);
      }
    }

    this.state.user = null;
    this.state.token = null;
    this.state.isAuthenticated = false;
    
    localStorage.removeItem('authToken');
    this.notifyListeners();
  }

  getState(): AuthState {
    return { ...this.state };
  }

  getAuthHeaders(): Record<string, string> {
    if (!this.state.token) return {};
    return {
      'Authorization': `Bearer ${this.state.token}`
    };
  }

  subscribe(callback: (state: AuthState) => void): () => void {
    this.listeners.push(callback);
    
    // Return unsubscribe function
    return () => {
      const index = this.listeners.indexOf(callback);
      if (index > -1) {
        this.listeners.splice(index, 1);
      }
    };
  }

  private notifyListeners() {
    this.listeners.forEach(callback => callback(this.getState()));
  }

  isAdmin(): boolean {
    return this.state.user?.role === 'admin';
  }
}

export const authManager = new AuthManager();
