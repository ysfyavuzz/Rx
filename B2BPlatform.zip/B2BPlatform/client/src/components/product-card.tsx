import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ShoppingCart } from "lucide-react";
import { Product } from "@shared/schema";
import { cartManager } from "@/lib/cart";
import { useToast } from "@/hooks/use-toast";

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const [quantity, setQuantity] = useState<number>(1);
  const { toast } = useToast();

  const handleAddToCart = () => {
    if (quantity > 0 && quantity <= product.stock) {
      cartManager.addItem(
        product.id,
        product.name,
        product.price,
        quantity,
        product.imageUrl || undefined
      );
      
      toast({
        title: "Başarılı!",
        description: `${quantity} adet ${product.name} sepete eklendi.`,
        duration: 3000,
      });
      
      setQuantity(1);
    } else {
      toast({
        title: "Hata!",
        description: "Lütfen geçerli bir adet giriniz.",
        variant: "destructive",
        duration: 3000,
      });
    }
  };

  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value) || 0;
    setQuantity(Math.max(0, Math.min(value, product.stock)));
  };

  const formatPrice = (priceInCents: number) => {
    return `₺${(priceInCents / 100).toLocaleString('tr-TR', { minimumFractionDigits: 2 })}`;
  };

  return (
    <Card className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow duration-200 overflow-hidden">
      <div className="aspect-w-16 aspect-h-12 bg-gray-100">
        {product.imageUrl ? (
          <img
            src={product.imageUrl}
            alt={product.name}
            className="w-full h-48 object-cover"
            onError={(e) => {
              // Fallback to placeholder if image fails to load
              (e.target as HTMLImageElement).src = `https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600`;
            }}
          />
        ) : (
          <div className="w-full h-48 bg-gray-200 flex items-center justify-center">
            <span className="text-gray-400 text-sm">Resim Yok</span>
          </div>
        )}
      </div>
      
      <CardContent className="p-4">
        <h3 className="font-semibold text-lg mb-2 line-clamp-1">
          {product.name}
        </h3>
        
        <p className="text-gray-600 text-sm mb-3 line-clamp-2">
          {product.description}
        </p>
        
        <div className="flex items-center justify-between mb-3">
          <span className="text-xl font-bold text-primary">
            {formatPrice(product.price)}
          </span>
          <Badge variant={product.stock > 0 ? "secondary" : "destructive"}>
            Stok: {product.stock} adet
          </Badge>
        </div>
        
        <div className="flex items-center gap-3">
          <Input
            type="number"
            placeholder="Adet"
            min="1"
            max={product.stock}
            value={quantity || ""}
            onChange={handleQuantityChange}
            className="flex-1 text-center"
            disabled={product.stock === 0}
          />
          <Button
            onClick={handleAddToCart}
            disabled={product.stock === 0 || quantity <= 0}
            className="bg-accent hover:bg-accent/90 text-white"
          >
            <ShoppingCart className="h-4 w-4 mr-2" />
            Ekle
          </Button>
        </div>
        
        {product.stock === 0 && (
          <p className="text-sm text-destructive mt-2 text-center">
            Stokta Yok
          </p>
        )}
      </CardContent>
    </Card>
  );
}
