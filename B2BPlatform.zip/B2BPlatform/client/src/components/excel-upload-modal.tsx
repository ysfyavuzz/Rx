import { useState } from "react";
import { Upload, FileText, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { authManager } from "@/lib/auth";

interface ExcelUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export function ExcelUploadModal({ isOpen, onClose, onSuccess }: ExcelUploadModalProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.type.includes('sheet') || file.name.endsWith('.xlsx') || file.name.endsWith('.xls')) {
        setSelectedFile(file);
      } else {
        toast({
          title: "Hata!",
          description: "Lütfen geçerli bir Excel dosyası seçin (.xlsx veya .xls)",
          variant: "destructive",
        });
      }
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      toast({
        title: "Hata!",
        description: "Lütfen bir dosya seçin.",
        variant: "destructive",
      });
      return;
    }

    setIsUploading(true);

    try {
      const formData = new FormData();
      formData.append('excel', selectedFile);

      const response = await fetch('/api/products/excel', {
        method: 'POST',
        headers: authManager.getAuthHeaders(),
        body: formData,
      });

      if (response.ok) {
        const result = await response.json();
        toast({
          title: "Başarılı!",
          description: result.message,
          duration: 5000,
        });
        
        if (result.errors && result.errors.length > 0) {
          console.warn('Excel upload warnings:', result.errors);
        }
        
        onSuccess();
        onClose();
        setSelectedFile(null);
      } else {
        const errorData = await response.json();
        toast({
          title: "Hata!",
          description: errorData.message || "Dosya yüklenirken bir hata oluştu.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Hata!",
        description: "Dosya yüklenirken bir hata oluştu. Lütfen tekrar deneyin.",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  const handleClose = () => {
    if (!isUploading) {
      setSelectedFile(null);
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Excel Dosyası Yükle</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
            <FileText className="mx-auto h-12 w-12 text-green-500 mb-4" />
            
            {selectedFile ? (
              <div className="space-y-2">
                <p className="text-sm font-medium text-gray-900">
                  {selectedFile.name}
                </p>
                <p className="text-xs text-gray-500">
                  {(selectedFile.size / 1024).toFixed(1)} KB
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedFile(null)}
                  disabled={isUploading}
                >
                  <X className="h-4 w-4 mr-2" />
                  Kaldır
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                <p className="text-gray-600 mb-4">
                  Excel dosyanızı buraya sürükleyin veya seçin
                </p>
                <label htmlFor="excel-file-input">
                  <Button
                    variant="default"
                    className="cursor-pointer"
                    disabled={isUploading}
                    asChild
                  >
                    <span>
                      <Upload className="h-4 w-4 mr-2" />
                      Dosya Seç
                    </span>
                  </Button>
                </label>
                <input
                  id="excel-file-input"
                  type="file"
                  accept=".xlsx,.xls"
                  onChange={handleFileSelect}
                  className="hidden"
                  disabled={isUploading}
                />
              </div>
            )}
          </div>
          
          <div className="text-sm text-gray-500 space-y-2">
            <p className="font-medium">Excel formatı:</p>
            <ul className="list-disc list-inside space-y-1 text-xs">
              <li>Ürün Adı (A sütunu)</li>
              <li>Açıklama (B sütunu)</li>
              <li>Fiyat (C sütunu)</li>
              <li>Stok (D sütunu)</li>
              <li>Kategori (E sütunu)</li>
            </ul>
            <p className="text-xs text-gray-400 mt-2">
              * İlk satır başlık olarak algılanacaktır
            </p>
          </div>
        </div>
        
        <div className="flex justify-end gap-3 pt-6">
          <Button 
            variant="outline" 
            onClick={handleClose}
            disabled={isUploading}
          >
            İptal
          </Button>
          <Button 
            onClick={handleUpload}
            disabled={!selectedFile || isUploading}
          >
            {isUploading ? "Yükleniyor..." : "Yükle"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
