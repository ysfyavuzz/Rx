import { useState, useEffect } from "react";
import { X, Trash2, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Separator } from "@/components/ui/separator";
import { cartManager } from "@/lib/cart";
import { authManager } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface CartSidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export function CartSidebar({ isOpen, onClose }: CartSidebarProps) {
  const [cartState, setCartState] = useState(cartManager.getState());
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const unsubscribe = cartManager.subscribe((state) => {
      setCartState(state);
    });

    return unsubscribe;
  }, []);

  const handleQuantityChange = (productId: number, quantity: number) => {
    cartManager.updateItemQuantity(productId, quantity);
  };

  const handleRemoveItem = (productId: number) => {
    cartManager.removeItem(productId);
  };

  const handleSubmitOrder = async () => {
    if (cartState.items.length === 0) {
      toast({
        title: "Hata!",
        description: "Sepetiniz boş.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    
    try {
      const orderData = {
        items: JSON.stringify(cartState.items),
        totalAmount: cartState.totalAmount,
        status: "pending"
      };

      await apiRequest('POST', '/api/orders', orderData);
      
      cartManager.clearCart();
      onClose();
      
      toast({
        title: "Sipariş Gönderildi!",
        description: "Siparişiniz e-posta ile gönderilmiştir. En kısa sürede size dönüş yapılacaktır.",
        duration: 5000,
      });
      
    } catch (error) {
      toast({
        title: "Hata!",
        description: "Sipariş gönderilirken bir hata oluştu. Lütfen tekrar deneyin.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatPrice = (priceInCents: number) => {
    return `₺${(priceInCents / 100).toLocaleString('tr-TR', { minimumFractionDigits: 2 })}`;
  };

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent side="right" className="w-96 sm:w-[400px]">
        <SheetHeader>
          <SheetTitle>Sepetim</SheetTitle>
        </SheetHeader>
        
        <div className="flex flex-col h-full mt-6">
          {cartState.items.length === 0 ? (
            <div className="flex-1 flex items-center justify-center">
              <p className="text-gray-500 text-center">
                Sepetiniz boş.<br />
                Ürünleri sepete ekleyerek başlayın.
              </p>
            </div>
          ) : (
            <>
              <div className="flex-1 overflow-y-auto space-y-4">
                {cartState.items.map((item) => (
                  <div key={item.productId} className="flex items-center gap-4 py-4 border-b last:border-b-0">
                    <div className="w-16 h-16 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                      {item.imageUrl ? (
                        <img
                          src={item.imageUrl}
                          alt={item.name}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = `https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200`;
                          }}
                        />
                      ) : (
                        <div className="w-full h-full bg-gray-200 flex items-center justify-center">
                          <span className="text-gray-400 text-xs">Resim</span>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex-1">
                      <h3 className="font-medium text-sm line-clamp-2">
                        {item.name}
                      </h3>
                      <div className="flex items-center justify-between mt-1">
                        <span className="text-primary font-semibold">
                          {formatPrice(item.price)}
                        </span>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-gray-600">Adet:</span>
                          <Input
                            type="number"
                            value={item.quantity}
                            onChange={(e) => handleQuantityChange(item.productId, parseInt(e.target.value) || 0)}
                            min="1"
                            className="w-16 h-8 text-xs text-center"
                          />
                        </div>
                      </div>
                    </div>
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleRemoveItem(item.productId)}
                      className="text-warning hover:text-warning/80"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
              
              <div className="border-t pt-6 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-lg font-semibold">Toplam:</span>
                  <span className="text-xl font-bold text-primary">
                    {formatPrice(cartState.totalAmount)}
                  </span>
                </div>
                
                <Button
                  onClick={handleSubmitOrder}
                  disabled={isSubmitting}
                  className="w-full bg-success hover:bg-success/90 text-white"
                >
                  <Send className="h-4 w-4 mr-2" />
                  {isSubmitting ? "Gönderiliyor..." : "Sipariş Gönder"}
                </Button>
                
                <p className="text-xs text-gray-500 text-center">
                  Siparişiniz e-posta ile gönderilecektir
                </p>
              </div>
            </>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}
