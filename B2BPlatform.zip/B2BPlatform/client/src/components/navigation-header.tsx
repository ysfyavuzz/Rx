import { Link, useLocation } from "wouter";
import { ShoppingCart, LogOut, Users, Package, ShoppingBag, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { authManager } from "@/lib/auth";
import { cartManager } from "@/lib/cart";
import { useState, useEffect } from "react";

interface NavigationHeaderProps {
  onCartClick: () => void;
}

export function NavigationHeader({ onCartClick }: NavigationHeaderProps) {
  const [location] = useLocation();
  const [user, setUser] = useState(authManager.getState().user);
  const [cartState, setCartState] = useState(cartManager.getState());

  useEffect(() => {
    const unsubscribeAuth = authManager.subscribe((state) => {
      setUser(state.user);
    });

    const unsubscribeCart = cartManager.subscribe((state) => {
      setCartState(state);
    });

    return () => {
      unsubscribeAuth();
      unsubscribeCart();
    };
  }, []);

  const handleLogout = () => {
    authManager.logout();
  };

  const isAdmin = user?.role === 'admin';

  const navigation = [
    { name: 'Ürünler', href: '/', icon: Package },
    { name: 'Siparişlerim', href: '/orders', icon: ShoppingBag },
    ...(isAdmin ? [{ name: 'Yönetim', href: '/admin', icon: Users }] : [])
  ];

  return (
    <header className="bg-white shadow-sm border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Link href="/">
                <h1 className="text-xl font-bold text-primary cursor-pointer">
                  B2B Sipariş Sistemi
                </h1>
              </Link>
            </div>
            
            {/* Desktop Navigation */}
            <nav className="hidden md:ml-8 md:flex md:space-x-8">
              {navigation.map((item) => {
                const isActive = location === item.href;
                return (
                  <Link key={item.name} href={item.href}>
                    <span className={`px-3 py-2 text-sm font-medium cursor-pointer transition-colors ${
                      isActive 
                        ? 'text-primary' 
                        : 'text-gray-500 hover:text-primary'
                    }`}>
                      {item.name}
                    </span>
                  </Link>
                );
              })}
            </nav>
          </div>

          <div className="flex items-center space-x-4">
            {/* Cart Button */}
            <Button
              variant="ghost"
              size="sm"
              className="relative p-2"
              onClick={onCartClick}
            >
              <ShoppingCart className="h-5 w-5" />
              {cartState.totalItems > 0 && (
                <Badge className="absolute -top-1 -right-1 bg-accent text-white text-xs h-5 w-5 flex items-center justify-center p-0">
                  {cartState.totalItems}
                </Badge>
              )}
            </Button>

            {/* User Info */}
            <div className="hidden sm:flex items-center space-x-3">
              <span className="text-sm text-gray-700">
                {user?.username}
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleLogout}
                className="text-gray-500 hover:text-primary"
              >
                <LogOut className="h-4 w-4" />
              </Button>
            </div>

            {/* Mobile Menu */}
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm" className="md:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-64">
                <div className="flex flex-col space-y-4 mt-6">
                  {navigation.map((item) => {
                    const Icon = item.icon;
                    const isActive = location === item.href;
                    return (
                      <Link key={item.name} href={item.href}>
                        <div className={`flex items-center space-x-3 px-3 py-2 rounded-lg cursor-pointer transition-colors ${
                          isActive 
                            ? 'bg-primary/10 text-primary' 
                            : 'text-gray-700 hover:bg-gray-100'
                        }`}>
                          <Icon className="h-5 w-5" />
                          <span>{item.name}</span>
                        </div>
                      </Link>
                    );
                  })}
                  
                  <div className="border-t pt-4">
                    <div className="flex items-center space-x-3 px-3 py-2 text-gray-700">
                      <span className="text-sm">{user?.username}</span>
                    </div>
                    <Button
                      variant="ghost"
                      className="w-full justify-start text-gray-500 hover:text-primary"
                      onClick={handleLogout}
                    >
                      <LogOut className="h-4 w-4 mr-3" />
                      Çıkış Yap
                    </Button>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
