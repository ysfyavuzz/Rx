import { useState, useEffect } from "react";
import { Plus, Edit, Trash2, Users, Package } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { NavigationHeader } from "@/components/navigation-header";
import { CartSidebar } from "@/components/cart-sidebar";
import { useToast } from "@/hooks/use-toast";
import { authManager } from "@/lib/auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { Product, User, InsertUser, InsertProduct } from "@shared/schema";

export default function Admin() {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [productForm, setProductForm] = useState<Partial<InsertProduct>>({
    name: "",
    description: "",
    price: 0,
    stock: 0,
    category: ""
  });
  const [userForm, setUserForm] = useState<InsertUser>({
    username: "",
    password: "",
    email: "",
    role: "user"
  });
  const { toast } = useToast();

  useEffect(() => {
    // Redirect if not admin
    if (!authManager.isAdmin()) {
      window.location.href = "/";
    }
  }, []);

  const { data: products = [], refetch: refetchProducts } = useQuery<Product[]>({
    queryKey: ['/api/products'],
    queryFn: async () => {
      const response = await fetch('/api/products', {
        headers: authManager.getAuthHeaders()
      });
      if (!response.ok) throw new Error('Failed to fetch products');
      return response.json();
    }
  });

  const createProductMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const response = await fetch('/api/products', {
        method: 'POST',
        headers: authManager.getAuthHeaders(),
        body: data
      });
      if (!response.ok) throw new Error('Failed to create product');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      setIsProductModalOpen(false);
      resetProductForm();
      toast({
        title: "Başarılı!",
        description: "Ürün başarıyla oluşturuldu.",
      });
    }
  });

  const updateProductMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: FormData }) => {
      const response = await fetch(`/api/products/${id}`, {
        method: 'PUT',
        headers: authManager.getAuthHeaders(),
        body: data
      });
      if (!response.ok) throw new Error('Failed to update product');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      setIsProductModalOpen(false);
      resetProductForm();
      toast({
        title: "Başarılı!",
        description: "Ürün başarıyla güncellendi.",
      });
    }
  });

  const deleteProductMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/products/${id}`, {
        method: 'DELETE',
        headers: authManager.getAuthHeaders()
      });
      if (!response.ok) throw new Error('Failed to delete product');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      toast({
        title: "Başarılı!",
        description: "Ürün başarıyla silindi.",
      });
    }
  });

  const createUserMutation = useMutation({
    mutationFn: async (userData: InsertUser) => {
      const response = await fetch('/api/users', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...authManager.getAuthHeaders()
        },
        body: JSON.stringify(userData)
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to create user');
      }
      return response.json();
    },
    onSuccess: () => {
      setIsUserModalOpen(false);
      resetUserForm();
      toast({
        title: "Başarılı!",
        description: "Kullanıcı başarıyla oluşturuldu.",
      });
    },
    onError: (error) => {
      toast({
        title: "Hata!",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const resetProductForm = () => {
    setProductForm({
      name: "",
      description: "",
      price: 0,
      stock: 0,
      category: ""
    });
    setEditingProduct(null);
  };

  const resetUserForm = () => {
    setUserForm({
      username: "",
      password: "",
      email: "",
      role: "user"
    });
  };

  const handleProductSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const formData = new FormData();
    formData.append('name', productForm.name || '');
    formData.append('description', productForm.description || '');
    formData.append('price', String(productForm.price || 0));
    formData.append('stock', String(productForm.stock || 0));
    formData.append('category', productForm.category || '');

    const fileInput = document.getElementById('productImage') as HTMLInputElement;
    if (fileInput?.files?.[0]) {
      formData.append('image', fileInput.files[0]);
    }

    if (editingProduct) {
      updateProductMutation.mutate({ id: editingProduct.id, data: formData });
    } else {
      createProductMutation.mutate(formData);
    }
  };

  const handleEditProduct = (product: Product) => {
    setEditingProduct(product);
    setProductForm({
      name: product.name,
      description: product.description,
      price: product.price,
      stock: product.stock,
      category: product.category
    });
    setIsProductModalOpen(true);
  };

  const handleDeleteProduct = (id: number) => {
    if (window.confirm('Bu ürünü silmek istediğinizden emin misiniz?')) {
      deleteProductMutation.mutate(id);
    }
  };

  const handleUserSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createUserMutation.mutate(userForm);
  };

  const formatPrice = (priceInCents: number) => {
    return `₺${(priceInCents / 100).toLocaleString('tr-TR', { minimumFractionDigits: 2 })}`;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <NavigationHeader onCartClick={() => setIsCartOpen(true)} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Yönetim Paneli</h1>
          <p className="text-gray-600">Ürünleri ve kullanıcıları yönetin</p>
        </div>

        <Tabs defaultValue="products" className="space-y-6">
          <TabsList>
            <TabsTrigger value="products" className="flex items-center gap-2">
              <Package className="h-4 w-4" />
              Ürünler
            </TabsTrigger>
            <TabsTrigger value="users" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Kullanıcılar
            </TabsTrigger>
          </TabsList>

          <TabsContent value="products">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Ürün Yönetimi</CardTitle>
                <Button onClick={() => setIsProductModalOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Yeni Ürün
                </Button>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Ürün</TableHead>
                      <TableHead>Kategori</TableHead>
                      <TableHead>Fiyat</TableHead>
                      <TableHead>Stok</TableHead>
                      <TableHead>Durum</TableHead>
                      <TableHead>İşlemler</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {products.map((product) => (
                      <TableRow key={product.id}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{product.name}</div>
                            <div className="text-sm text-gray-500 line-clamp-1">
                              {product.description}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary">{product.category}</Badge>
                        </TableCell>
                        <TableCell className="font-medium">
                          {formatPrice(product.price)}
                        </TableCell>
                        <TableCell>{product.stock}</TableCell>
                        <TableCell>
                          <Badge variant={product.isActive ? "default" : "secondary"}>
                            {product.isActive ? "Aktif" : "Pasif"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleEditProduct(product)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleDeleteProduct(product.id)}
                              className="text-destructive hover:text-destructive"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Kullanıcı Yönetimi</CardTitle>
                <Button onClick={() => setIsUserModalOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Yeni Kullanıcı
                </Button>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center py-8">
                  Kullanıcı listesi gösterilecek. Şu anda sadece yeni kullanıcı ekleme özelliği aktif.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Product Modal */}
      <Dialog open={isProductModalOpen} onOpenChange={setIsProductModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {editingProduct ? 'Ürün Düzenle' : 'Yeni Ürün Ekle'}
            </DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleProductSubmit} className="space-y-4">
            <div>
              <Label htmlFor="productName">Ürün Adı</Label>
              <Input
                id="productName"
                value={productForm.name || ''}
                onChange={(e) => setProductForm(prev => ({ ...prev, name: e.target.value }))}
                required
              />
            </div>
            
            <div>
              <Label htmlFor="productDescription">Açıklama</Label>
              <Textarea
                id="productDescription"
                value={productForm.description || ''}
                onChange={(e) => setProductForm(prev => ({ ...prev, description: e.target.value }))}
                required
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="productPrice">Fiyat (₺)</Label>
                <Input
                  id="productPrice"
                  type="number"
                  step="0.01"
                  value={productForm.price ? (productForm.price / 100) : ''}
                  onChange={(e) => setProductForm(prev => ({ 
                    ...prev, 
                    price: Math.round(parseFloat(e.target.value || '0') * 100)
                  }))}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="productStock">Stok</Label>
                <Input
                  id="productStock"
                  type="number"
                  value={productForm.stock || ''}
                  onChange={(e) => setProductForm(prev => ({ 
                    ...prev, 
                    stock: parseInt(e.target.value || '0')
                  }))}
                  required
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="productCategory">Kategori</Label>
              <Input
                id="productCategory"
                value={productForm.category || ''}
                onChange={(e) => setProductForm(prev => ({ ...prev, category: e.target.value }))}
                required
              />
            </div>
            
            <div>
              <Label htmlFor="productImage">Ürün Resmi</Label>
              <Input
                id="productImage"
                type="file"
                accept="image/*"
              />
            </div>
            
            <div className="flex justify-end gap-3 pt-4">
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => {
                  setIsProductModalOpen(false);
                  resetProductForm();
                }}
              >
                İptal
              </Button>
              <Button 
                type="submit"
                disabled={createProductMutation.isPending || updateProductMutation.isPending}
              >
                {editingProduct ? 'Güncelle' : 'Oluştur'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* User Modal */}
      <Dialog open={isUserModalOpen} onOpenChange={setIsUserModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Yeni Kullanıcı Ekle</DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleUserSubmit} className="space-y-4">
            <div>
              <Label htmlFor="username">Kullanıcı Adı</Label>
              <Input
                id="username"
                value={userForm.username}
                onChange={(e) => setUserForm(prev => ({ ...prev, username: e.target.value }))}
                required
              />
            </div>
            
            <div>
              <Label htmlFor="email">E-posta</Label>
              <Input
                id="email"
                type="email"
                value={userForm.email}
                onChange={(e) => setUserForm(prev => ({ ...prev, email: e.target.value }))}
                required
              />
            </div>
            
            <div>
              <Label htmlFor="password">Şifre</Label>
              <Input
                id="password"
                type="password"
                value={userForm.password}
                onChange={(e) => setUserForm(prev => ({ ...prev, password: e.target.value }))}
                required
              />
            </div>
            
            <div>
              <Label htmlFor="role">Rol</Label>
              <Select value={userForm.role} onValueChange={(value) => setUserForm(prev => ({ ...prev, role: value as 'admin' | 'user' }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="user">Kullanıcı</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex justify-end gap-3 pt-4">
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => {
                  setIsUserModalOpen(false);
                  resetUserForm();
                }}
              >
                İptal
              </Button>
              <Button 
                type="submit"
                disabled={createUserMutation.isPending}
              >
                Oluştur
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <CartSidebar 
        isOpen={isCartOpen} 
        onClose={() => setIsCartOpen(false)} 
      />
    </div>
  );
}
